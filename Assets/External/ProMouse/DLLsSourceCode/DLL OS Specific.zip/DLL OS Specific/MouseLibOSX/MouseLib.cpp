//
//  MouseLib.cpp
//  MouseLib
//
//  Created by Juan Sebastian Muñoz on 5/26/13.
//  Copyright (c) 2013 Juan Sebastian Muñoz. All rights reserved.
//

#include "MouseLib.h"

void _MoveCursorToPoint(int xPos, int yPos) {
    //CGDisplayMoveCursorToPoint(kCGDirectMainDisplay,CGPointMake(xPos, yPos));
    CGWarpMouseCursorPosition(CGPointMake(xPos, yPos));
    CGAssociateMouseAndMouseCursorPosition(true);
}

int _GetGlobalMousePositionVertical() {
    CGEventRef myEvent = CGEventCreate(NULL);
    CGPoint p = CGEventGetLocation(myEvent);
    return (p.y);
}

int _GetGlobalMousePositionHorizontal() {
    CGEventRef myEvent = CGEventCreate(NULL);
    CGPoint p = CGEventGetLocation(myEvent);
    return p.x;
    
}

/*int _GetDisplayWidth(){
    return CGDisplayPixelsWide(kCGDirectMainDisplay);

}

int _GetDisplayHeight(){
    return CGDisplayPixelsHigh(kCGDirectMainDisplay);    
}*/