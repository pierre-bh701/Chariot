//
//  MouseLib.h
//  MouseLib
//
//  Created by Juan Sebastian Muñoz on 5/26/13.
//  Copyright (c) 2013 Juan Sebastian Muñoz. All rights reserved.
//

#include <iostream>
#include <ApplicationServices/ApplicationServices.h>

using namespace std;
extern "C" {
    void _MoveCursorToPoint(int, int);
    int _GetGlobalMousePositionHorizontal();
    int _GetGlobalMousePositionVertical();
    //int _GetDisplayWidth();
    //int _GetDisplayHeight();
}
