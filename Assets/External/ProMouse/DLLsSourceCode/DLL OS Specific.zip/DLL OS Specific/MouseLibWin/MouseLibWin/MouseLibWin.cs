using System.Collections;
using System.Runtime.InteropServices;

public class MouseLibWin {
 	[DllImport("user32.dll")]
    private static extern int SetCursorPos(int x, int y);

	// Retrieves the cursor's position, in screen coordinates.
	[DllImport("user32.dll")]
	private static extern bool GetCursorPos(out POINT mousePos);
	
	// Struct representing a point.
	[StructLayout(LayoutKind.Sequential)]
	private struct POINT {
    	public int X, Y;
	}
	
	public static void _MoveCursorToPoint(int x, int y) {
		SetCursorPos (x,y);
	}
	
	public static int _GetGlobalMousePositionHorizontal() {
    	POINT mousePos;
    	GetCursorPos(out mousePos);
    	//bool success = User32.GetCursorPos(out lpPoint); if (!success)
    	return mousePos.X;
	}
	public static int _GetGlobalMousePositionVertical() {
    	POINT mousePos;
    	GetCursorPos(out mousePos);
    	//bool success = User32.GetCursorPos(out lpPoint); if (!success)
    	return mousePos.Y;
	}
}