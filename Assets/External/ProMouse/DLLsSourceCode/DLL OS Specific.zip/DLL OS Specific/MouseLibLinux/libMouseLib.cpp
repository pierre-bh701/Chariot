//g++ file.cpp -lX11 -o main
/*
  1) g++ -Wall -c -fPIC MouseLibLinux.cpp -lX11 -o MouseLibLinux.o
  2) g++ -Wall MouseLibLinux.o -shared -o MouseLibLinux.so
 */
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <X11/Xlib.h>

extern "C" {
    void _MoveCursorToPoint(int x, int y) {
        Display *display = XOpenDisplay(NULL);
        Window rootWindow = XRootWindow(display, 0);
        if(display == NULL) {
            fprintf(stderr, "Error opening display for moving mouse.\n");
            exit(EXIT_FAILURE);
        }
        XSelectInput(display, rootWindow, KeyReleaseMask);
        XWarpPointer(display, None, rootWindow, 0,0,0,0, x, y);
        XFlush(display);
        XCloseDisplay(display);
    }
    
    int _GetGlobalMousePositionHorizontal() {
        Display *dsp = XOpenDisplay(NULL);
        if(!dsp){
            fprintf(stderr, "Error opening display for getting mouse position.\n");
            exit(EXIT_FAILURE);
        }
        XEvent event;
        /* get info about current pointer position */
        XQueryPointer(dsp, RootWindow(dsp, DefaultScreen(dsp)),
                      &event.xbutton.root, &event.xbutton.window,
                      &event.xbutton.x_root, &event.xbutton.y_root,
                      &event.xbutton.x, &event.xbutton.y,
                      &event.xbutton.state);
        int horizPos = event.xbutton.x;
        XCloseDisplay(dsp);
        return horizPos;
    }
    int _GetGlobalMousePositionVertical() {
        Display *dsp = XOpenDisplay(NULL);
        if(!dsp){
            fprintf(stderr, "Error opening display for getting mouse position.\n");
            exit(EXIT_FAILURE);
        }
        XEvent event;
        /* get info about current pointer position */
        XQueryPointer(dsp, RootWindow(dsp, DefaultScreen(dsp)),
                      &event.xbutton.root, &event.xbutton.window,
                      &event.xbutton.x_root, &event.xbutton.y_root,
                      &event.xbutton.x, &event.xbutton.y,
                      &event.xbutton.state);
        int vertPos = event.xbutton.y;
        XCloseDisplay(dsp);
        return vertPos;
    }
}
